import 'package:flutter/material.dart';
import 'package:sign_in_and_sign_out_ui/sign_up.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(title: const Text('Sign In'),),
        body:  MyStatefullWidget(),
      ),
     );
  }
}

class MyStatefullWidget extends StatefulWidget{
  @override
  State<MyStatefullWidget> createState() => _MyStatefullWidgetState();
}

class _MyStatefullWidgetState extends State<MyStatefullWidget> {
  TextEditingController nameController = TextEditingController();
  TextEditingController passController = TextEditingController();
    @override
  Widget build(BuildContext context) {
      return Padding(padding: const EdgeInsets.all(10),
      child: ListView(
            padding: const EdgeInsets.fromLTRB(10, 50, 10, 10),
        children:<Widget> [
          Container(
            child: const Text('Login',
              style: TextStyle(
                fontSize: 40,
                fontWeight: FontWeight.w500,
                color: Colors.transparent, // Step 2 SEE HERE
                shadows: [Shadow(offset: Offset(0, -10), color: Colors.black,)], // Step 3 SEE HERE
                decoration: TextDecoration.underline,
                decorationColor: Colors.black,
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(0,50, 0, 0),
            alignment: Alignment.center,
            child: TextField(
              controller: nameController,
              style: TextStyle(color: Colors.green),
              decoration: const InputDecoration(
                hintText: 'Email',
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(0, 20, 0, 0),
            alignment: Alignment.center,
            child: TextField(
              controller: passController,
              style: TextStyle(color: Colors.black),
              decoration: const InputDecoration(hintText: 'Password'),
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
            alignment: Alignment.bottomLeft,
            child: TextButton(
              onPressed: (){},
              child: const Text('Forgot Password?',
                style: TextStyle(color: Colors.black,),
              ),
            ),
          ),
          Container(
              height: 60,
              padding: const EdgeInsets.fromLTRB(0, 20, 0, 0),
              child: ElevatedButton(
                child: const Text('Login',style: TextStyle(fontSize: 20,),),
                onPressed: () {
                  print(nameController.text);
                  print(passController.text);
                },
                style: ElevatedButton.styleFrom(
                  primary: Colors.green,
                ),
              )
          ),
          Container(
            margin: EdgeInsets.fromLTRB(0, 50, 0, 0),
            padding: const EdgeInsets.fromLTRB(20, 10, 0, 0),
            child: Text("Don't have an account?"),
          ),
          Container(
              height: 60,
              margin: EdgeInsets.fromLTRB(0, 20, 0, 0),
              padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.green,width: 2)),
              child: ElevatedButton(
                child: const Text('CREAT ACCOUNT',style: TextStyle(fontSize: 20,color: Colors.green),),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>SignUp()));
                },
                style: ElevatedButton.styleFrom(
                  primary: Colors.white,
                ),
              )
          ),
        ],
      ),
      );
  }
}