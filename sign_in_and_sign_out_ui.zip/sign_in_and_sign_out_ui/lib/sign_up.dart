import 'package:flutter/material.dart';
import 'package:sign_in_and_sign_out_ui/main.dart';

class SignUp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(title: Text('Sign Up'),),
        body: SignUpWidget(),
      ),
    );
  }
}
class SignUpWidget extends StatefulWidget{
  @override
  State<SignUpWidget> createState() => _SignUpWidgetState();
}

class _SignUpWidgetState extends State<SignUpWidget> {
  TextEditingController nameController = TextEditingController();
  TextEditingController passController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: <Widget>[
        Container(
          padding: const EdgeInsets.fromLTRB(10, 50, 10, 10),
          child: const Text('Create Account',
            style: TextStyle(
              fontSize: 40,
              fontWeight: FontWeight.w500,
              color: Colors.transparent, // Step 2 SEE HERE
              shadows: [Shadow(offset: Offset(0, -10), color: Colors.black,)], // Step 3 SEE HERE
              decoration: TextDecoration.underline,
              decorationColor: Colors.black,
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.fromLTRB(0,50, 0, 0),
          alignment: Alignment.center,
          child: TextField(
            controller: nameController,
            style: TextStyle(color: Colors.green),
            decoration: const InputDecoration(
              hintText: 'Email',
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.fromLTRB(0, 20, 0, 0),
          alignment: Alignment.center,
          child: TextField(
            controller: passController,
            style: TextStyle(color: Colors.black),
            decoration: const InputDecoration(hintText: 'Password'),
          ),
        ),
        Container(
          padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
          alignment: Alignment.bottomLeft,
          child: TextButton(
            onPressed: (){},
            child: const Text('Forgot Password?',
              style: TextStyle(color: Colors.black,),
            ),
          ),
        ),
        Container(
            height: 60,
            padding: const EdgeInsets.fromLTRB(0, 20, 0, 0),
            child: ElevatedButton(
              child: const Text('CREATE',style: TextStyle(fontSize: 20,),),
              onPressed: () {
                print(nameController.text);
                print(passController.text);
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.green,
              ),
            )
        ),
        Container(
          margin: EdgeInsets.fromLTRB(0, 50, 0, 0),
          padding: const EdgeInsets.fromLTRB(20, 10, 0, 0),
          child: Text("Already have an account?"),
        ),
        Container(
            height: 60,
            margin: EdgeInsets.fromLTRB(0, 20, 0, 0),
            padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
            decoration: BoxDecoration(
                border: Border.all(color: Colors.green,width: 2)),
            child: ElevatedButton(
              child: const Text('LOGIN',style: TextStyle(fontSize: 20,color: Colors.green),),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context)=>MyApp()));
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.white,
              ),
            )
        ),
      ],
    );
  }

}