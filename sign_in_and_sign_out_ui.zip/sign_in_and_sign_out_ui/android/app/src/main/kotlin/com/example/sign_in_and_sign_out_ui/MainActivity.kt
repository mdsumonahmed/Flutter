package com.example.sign_in_and_sign_out_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
